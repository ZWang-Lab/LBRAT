library(LBRAT)

library("Slurm")
jobID <- slurm.array_job_id()
arrayID <- slurm.array_task_id()

output.gee=paste("gee",jobID,"-", arrayID,".RData",sep="")
output.glmm=paste("glmm",jobID,"-", arrayID,".RData",sep="")

disease.para<- list(model = "dominance", gamma = 0.1,  p1=0.5, p2=0.1, D=0)

oversample =c('random', 'baseline', 'sum')
phenomodel =c('logistic', 'liability')
cor = c('mixture', 'ar1', 'ind')
gamma = seq(0.3,0.38,by = 0.02)



for(o in 1:3){
  for(p in 1:2){
      for (c in 1:3){
        foldername = paste(phenomodel[p],"_",oversample[o], sep = "")
        if(!dir.exists(foldername)){dir.create(foldername)}
        for(g in 1:length(gamma)){
          disease.para$gamma= gamma[g];
              p0<-lbrat_simu(2000, n.time = 5, phe.model = phenomodel[p], oversampling =oversample[o], onlypower = T,disease.para =disease.para )

              gee0 <- lbrat_est.gee(p0$phe.long, p0$phe.time, p0$phe.cov, corstr = cor[c])
              power10<- lbrat_test(gee0, p0$snp.mat)[3,]
              if(c==1){
                glmm0 <- lbrat_est.glmm(p0$phe.long, p0$phe.time, p0$phe.cov);
                power10glmm <- lbrat_test(glmm0,p0$snp.mat)[3,];
              }
            save(power10, file = paste(foldername,"/", cor[c], "_gamma_", gamma[g],"_", output.gee, sep =""));
            if(c==1){save(power10glmm, file = paste(foldername,"/", "gamma_", gamma[g],"_", output.glmm, sep =""));}
	}
}}}














