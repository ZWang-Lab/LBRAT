rm(list = ls())
getFrom=function(file, name){e=new.env();load(file,env=e);e[[name]]}

rgs = commandArgs(trailingOnly=TRUE)
id <- rgs[2]
cor <- rgs[1]
print(cor)

myresult <- as.data.frame(matrix( nrow = 10^3, ncol = 5)); 
gammas = seq(0.3, 0.38, by = 0.02)
powers = matrix(0, length(gammas), 2)
for(g in 1:length(gammas)){
for (i in 1: 1000){
	input.name = paste(cor,"_gamma_",gammas[g], "_gee", id, "-", i, ".RData", sep = "")

	if(file.exists(input.name)){
		temp = getFrom(input.name,"power10")
		myresult[i,]=  temp
	}

	if(!file.exists(input.name)) print(i)
        }

powers[g,] = apply(myresult[,3:4],2, function(x)sum(x<10^-3))/nrow(myresult)
}
print(t(powers))
save(powers, file = paste("summary_", cor, ".RData", sep = ""))






#pdf(file = paste('plot-', fil,".pdf",  sep =""))

