rm(list = ls())
getFrom=function(file, name){e=new.env();load(file,env=e);e[[name]]}
rgs = commandArgs(trailingOnly=TRUE)
id <- rgs[1]
print("glmm")


myresult <- as.data.frame(matrix( nrow = 10^3, ncol = 5)); 
gammas = seq(0.3, 0.38, by = 0.02)
powers = matrix(0, length(gammas), 2)
for(g in 1:length(gammas)){
for (i in 1: 1000){
        count = 0;
	input.name = paste("gamma_",gammas[g], "_glmm",id, "-", i, ".RData", sep = "")
    
	if(file.exists(input.name)){
		temp = getFrom(input.name,"power10glmm")
		myresult[i,]=  temp
		count = count +1
                if(count %% 100==0) print(count)
	}

	if(!file.exists(input.name)) print(i)
        }

powers[g,] = apply(myresult[,3:4],2, function(x)sum(x<10^-3))/nrow(myresult)
}
print(t(powers))
save(powers, file = paste("summary_glmm", id, ".RData", sep = ""))






#pdf(file = paste('plot-', fil,".pdf",  sep =""))

