cd logistic_random/
echo $PWD
echo $PWD >$(tty)
Rscript ../summarypower.R ar1 $1
Rscript ../summarypower.R ind $1
Rscript ../summarypower.R mixture $1
Rscript ../summarypowerglmm.R $1
cd ../logistic_baseline/
echo $PWD
echo $PWD >$(tty)
Rscript ../summarypower.R ar1 $1
Rscript ../summarypower.R ind $1
Rscript ../summarypower.R mixture $1
Rscript ../summarypowerglmm.R $1
cd ../logistic_sum/
echo $PWD
echo $PWD >$(tty)
Rscript ../summarypower.R ar1 $1
Rscript ../summarypower.R ind $1
Rscript ../summarypower.R mixture $1
Rscript ../summarypowerglmm.R $1
cd ../liability_random/
echo $PWD
echo $PWD >$(tty)
Rscript ../summarypower.R ar1 $1
Rscript ../summarypower.R ind $1
Rscript ../summarypower.R mixture $1
Rscript ../summarypowerglmm.R $1
cd ../liability_baseline/
echo $PWD
echo $PWD >$(tty)
Rscript ../summarypower.R ar1 $1
Rscript ../summarypower.R ind $1
Rscript ../summarypower.R mixture $1
Rscript ../summarypowerglmm.R $1
cd ../liability_sum/
echo $PWD
echo $PWD >$(tty)
Rscript ../summarypower.R ar1 $1
Rscript ../summarypower.R ind $1
Rscript ../summarypower.R mixture $1
Rscript ../summarypowerglmm.R $1

