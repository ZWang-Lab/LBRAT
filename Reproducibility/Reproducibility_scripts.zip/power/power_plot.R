require(cowplot)
require(grid)
require(gridExtra)
library(ggplot2)
library(gtable)

power <- read.table('cat_power.txt', header = T) 
power_long = reshape(power, varying = c("X0.3", "X0.32", "X0.34", "X0.36", "X0.38"), v.name = "power",timevar = 'gamma', times = seq(0.3, 0.38, by = 0.02), direction = "long")

power_long$Group = paste(power_long$Corr.M, power_long$pro.retro, sep = ".")
power_long$Group = as.factor(power_long$Group)
levels(power_long$Group)<-c('GEE(AR1)', 'L-BRAT(AR1)', 'GMMAT', "RGMMAT", "GEE(ind)", "L-BRAT(ind)", "GEE(mix)", "L-BRAT(mix)")
power_long$Group = factor(power_long$Group,levels(power_long$Group)[c(5,6,1,2,7,8,3,4)])

power_long$Model = factor(power_long$Mode, levels(power_long$Mode)[c(2,1)])
power_long$Ascern = factor(power_long$Ascern, levels(power_long$Ascern)[c(2,1,3)])


model = levels(power_long$Model)
ascern = levels(power_long$Ascern)

# create six panels for each of the plot
pp1 = power_long[which(power_long$Model == model[1] & power_long$Ascern == ascern[1]), ]

g  = ggplot(pp1, aes(gamma, power, color = Group, linetype = Group))+geom_line()+scale_linetype_manual("",values = rep(c("dotdash","solid"), 4))+ labs(x = expression(theta), y = "Power", face = "bold", size = 25) +scale_color_manual( "",values=rep(c("blue", "red", "green","#000001"),each=2))+ theme(axis.title.x=element_blank())+theme(axis.title.y=element_blank())+ggtitle('Random')+theme(plot.title = element_text(size = 12, face = NULL))+ theme(legend.direction = "horizontal", legend.text = element_text(size = 10)) + geom_point(aes(shape = factor(Group))) + scale_shape_manual("", values =rep(c(15:18), each = 2))

g1 = g + theme(axis.title.y=element_text(angle = 90, size = 12))+theme(legend.position="none")
g2 =  g %+% power_long[which(power_long$Model == model[1] & power_long$Ascern == ascern[2]), ]+ggtitle('Baseline')+theme(legend.position="none")
g3 =  g  %+% power_long[which(power_long$Model == model[1] & power_long$Ascern == ascern[3]), ]+ggtitle('Sum')+theme(legend.position="none")

g4 =  g %+% power_long[which(power_long$Model == model[2] & power_long$Ascern == ascern[1]), ] + ggtitle('')+theme(axis.title.y=element_text(angle = 90, size = 12)) + theme(axis.title.x = element_text())+theme(legend.position="none")
g5 =  g %+% power_long[which(power_long$Model == model[2] & power_long$Ascern == ascern[2]), ]+theme(axis.title.x=element_text())+ggtitle("")+theme(legend.position="none")

g6 =  g %+% power_long[which(power_long$Model == model[2] & power_long$Ascern == ascern[3]), ]+theme(axis.title.x=element_text())+ggtitle("")+theme(legend.position="none")

l1 = textGrob("Logistic Mixed Model", gp=gpar(fontface = "bold", fontsize = 13))
l2 = textGrob("Liability Threshold Model",gp=gpar(fontface = "bold", fontsize = 13))

mylegend = gtable_filter(ggplotGrob(g), "guide-box") 

# lay out the legend and the plot
lay = rbind(c(1,1,1),
					c(2, 2, 2),
					c(3, 3, 3),
					c(4, 4, 4),
					c(NA,5, NA))

tiff('fig1.tiff',width = 9, height = 6, units = 'in', res = 300)
p = grid.arrange(l1, arrangeGrob(g1,g2,g3, ncol = 3, widths = c(4, 4, 4)),l2, arrangeGrob(g4,g5,g6, ncol = 3, widths = c(4, 4, 4)), mylegend,layout_matrix = lay, heights=c(0.8, 6, 0.5, 6, 0.8), ncol = 1 , vp=viewport(width=0.9, height=0.95))
dev.off()


