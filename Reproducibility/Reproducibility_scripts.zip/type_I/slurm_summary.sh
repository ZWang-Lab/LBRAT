#!/bin/bash
#SBATCH --job-name=test
#SBATCH --nodes=1
#SBATCH --time=10:00:00
#SBATCH --mem=100G
#SBATCH --mail-type=END,FAIL

cd $SLURM_SUBMIT_DIR
sh summaryjobs.sh "$1"
