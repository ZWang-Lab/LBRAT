rm(list = ls())
getFrom=function(file, name){e=new.env();load(file,env=e);e[[name]]}
# getFrom("job-2389450[1].mgt1.ruddle.hpc.yale.internal.RData","result")
message("Please enter a file name ...\n")
#fil <- readLines(con="stdin", 1)
args<-commandArgs(TRUE)
fil <- args[1]
 
 cat('job #',fil, "\n")

myresult <- as.data.frame(matrix( nrow = 10^5, ncol = 5)); 
count = 0
for (i in 1: 1000){
	input.name = paste(fil,"-", i, ".RData", sep = "")
    
#	input.name = paste("job-", fil,"-", i, ".RData", sep = "")
	if(file.exists(input.name)){
		temp = getFrom(input.name,"result.glmm")
		myresult[(i*1000-999):(i*1000),]=  temp[1:1000,]
		count = count +1
                if(count %% 100==0) print(count)
	}

	if(!file.exists(input.name)) print(i)

}

save(myresult, file =paste("summary-",fil,".RData", sep = ""))

cat("num of simu: ", nrow(myresult), "\n")

type1 <- function(x, a) apply(x, 2, function(x)sum(x<a))/nrow(x);
cat('0.05', '\n');
type1(myresult[,3:4], 0.05)

cat('0.01,', '\n');
type1(myresult[,c(3,4)], 0.01)

cat('0.001', '\n');
type1(myresult[,3:4], 0.001)




#pdf(file = paste('plot-', fil,".pdf",  sep =""))

