library(LBRAT)
library("Slurm")
jobID <- slurm.array_job_id()
arrayID <- slurm.array_task_id()

output.gee=paste("gee",jobID,"-", arrayID,".RData",sep="")
output.glmm=paste("glmm",jobID,"-", arrayID,".RData",sep="")

oversample =c('random', 'baseline', 'sum')
phenomodel =c('logistic', 'liability')
cor = c('mixture', 'ar1', 'ind')

for( o in 1:3)
  {
  for(p in 1:2)
    {
      foldername = paste(phenomodel[p],"_",oversample[o], sep = "")
      if(!dir.exists(foldername)){dir.create(foldername)}
      p0<-lbrat_simu(2000, n.time = 5, phe.model = phenomodel[p], oversampling =oversample[o])
        for (c in 1:3)
          {
          gee0 <- lbrat_est.gee(p0$phe.long, p0$phe.time, p0$phe.cov, corstr = cor[c])
          result.gee <- lbrat_test(gee0, p0$snp.mat)
          save(result.gee, file = paste(foldername,"/", cor[c], "_",  output.gee, sep =""));
          }
        glmm0<- lbrat_est.glmm(p0$phe.long, p0$phe.time, p0$phe.cov)
        result.glmm <- lbrat_test(glmm0,p0$snp.mat)
        save(result.glmm, file = paste(foldername,"/", output.glmm, sep =""));
    }
  }



