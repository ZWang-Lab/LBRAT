
cd logistic_random/
Rscript ../summarygee.R ar1_gee$1
Rscript ../summarygee.R ind_gee$1
Rscript ../summarygee.R mixture_gee$1
Rscript ../summaryglm.R glmm$1
cd ../logistic_baseline/
Rscript ../summarygee.R ar1_gee$1
Rscript ../summarygee.R ind_gee$1
Rscript ../summarygee.R mixture_gee$1
Rscript ../summaryglm.R glmm$1
cd ../logistic_sum/
Rscript ../summarygee.R ar1_gee$1
Rscript ../summarygee.R ind_gee$1
Rscript ../summarygee.R mixture_gee$1
Rscript ../summaryglm.R glmm$1
cd ../liability_random/
Rscript ../summarygee.R ar1_gee$1
Rscript ../summarygee.R ind_gee$1
Rscript ../summarygee.R mixture_gee$1
Rscript ../summaryglm.R glmm$1
cd ../liability_baseline/
Rscript ../summarygee.R ar1_gee$1
Rscript ../summarygee.R ind_gee$1
Rscript ../summarygee.R mixture_gee$1
Rscript ../summaryglm.R glmm$1
cd ../liability_sum/
Rscript ../summarygee.R ar1_gee$1
Rscript ../summarygee.R ind_gee$1
Rscript ../summarygee.R mixture_gee$1
Rscript ../summaryglm.R glmm$1

